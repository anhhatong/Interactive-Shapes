let showPath = true;
let ball;
let leftClick = 0; // keep track of left click

function setup() {
  document.oncontextmenu = function() { // right click without context menu
    return false;
  }
  ball = new Ball(50, 0, 3, 0, 3); // our ball object
  createCanvas(window.innerWidth, window.innerHeight);
  textAlign(CENTER);
}

function draw() {
  if (showPath) {
    background(30);
  }
  if (leftClick == 0) {
    fill(random(100, 255), random(100, 255), random(100, 255));
    text("Click Anywhere to Start", window.innerWidth/2, window.innerHeight/2); // initial text
    textSize(30);
  }
  if (leftClick != 0) { // ball only appears after the first left click
    text("Left Click = relocate ball | Hold Left Click = drag | Right Click = stop/release color | 'R' = ring/ball mode", window.innerWidth/2, 20);
    text("Hold ENTER = go crazy | SPC = stop/release ball | 'P' = show path | 'L' = enlarge | 'S' = shrink | 'Q' = quit", window.innerWidth/2, window.innerHeight-10);
    textSize(20);
    ball.display();
    ball.move();
  }
}
function keyPressed() {
  switch (key) {
    // press 'p' to trace path
  case 'p':
  case 'P':
    showPath = !showPath;
    break;
    // press 'l' to enlarge ball
  case 'l':
  case 'L':
    ball.grow();
    break;
    // press 's' to shrink ball
  case 's':
  case 'S':
    ball.shrink();
    break;
  case 'r':
  case 'R':
    ball.ringMode();
    break;
    // press SPACE to stop ball
  case ' ':
    ball.stop();
    break;
    // press ENTER to move and speed ball up randomly
  case 'v':
    ball.speedUp();
    break;
    // press 'q' to end program
  case 'q':
  case 'Q':
    remove();
    break;
  }
}

function keyReleased() {
  if (key === 'v') {// when ENTER is released, ball is restored to the previous state
    ball.toOriginalSpeed();
  }
}

function mousePressed() {
  ball.mouseClick();
  leftClick = 1; // set leftClick to 1 after the first click
}

function mouseDragged() { // drag ball around
  ball.mouseClick();
}

class Ball{
  constructor(diameter, x, dx, y, dy) {
    this.diameter = diameter;
    this.x = x;
    this.dx = dx;
    this.y = y;
    this.dy = dy;
    this.rightClick = false; // keep track of our rightClick
    this.stopState = false; // keep track of the state of the ball (moving or stopped)
    this.ring = false;

  }

  display() {
    if (this.ring == true) { // when in ring form
      noFill();
      if (this.rightClick == false) {
        stroke(random(100, 255), random(100, 255), random(100, 255), 100); //random colors
      }
      strokeWeight(1);
      ellipse (this.x, this.y, this.diameter, this.diameter);
      return;
    } 
    if (this.rightClick == false) { // right click to stop at a color, and the next right click will undo it
      fill(random(100, 255), random(100, 255), random(100, 255), 100); // ball's fill changes colors
    } 
    noStroke();
    ellipse (this.x, this.y, this.diameter, this.diameter);
  }

  move() {
    // check if the arc of the ball touches the edges of the window
    // if so, bounce back
    if ((this.x + this.dx > window.innerWidth - this.diameter/2 || this.x + this.dx < this.diameter/2)) {
      this.dx = -this.dx;
    }
    if ((this.y + this.dy > window.innerHeight - this.diameter/2 || this.y + this.dy < this.diameter/2)) {
      this.dy = -this.dy;
    }
    // if not, keep moving
    this.x+=this.dx;
    this.y+=this.dy;
  }

  mouseClick() {
    if (mouseButton == LEFT) { // left click to take the ball to a new spot
      // when the user clicks close to the 4 corners and window edges, make sure the ball does not go out of bound
      if ((mouseX > window.innerWidth - this.diameter/2) && (mouseY > window.innerHeight - this.diameter/2)) { // lower right corner
        this.x = window.innerWidth - this.diameter/2;
        this.y = window.innerHeight - this.diameter/2;
        return;
      }

      if ((mouseX > window.innerWidth - this.diameter/2) && (mouseY < this.diameter/2)) { // upper right corner
        this.x = window.innerWidth - this.diameter/2;
        this.y = this.diameter/2;
        return;
      }

      if ((mouseX < this.diameter/2) && (mouseY > window.innerHeight - this.diameter/2)) { // lower left corner
        this.x = this.diameter/2;
        this.y = window.innerHeight - this.diameter/2;
        return;
      }

      if ((mouseX < this.diameter/2) && (mouseY < this.diameter/2)) { // upper left corner
        this.x = this.diameter/2;
        this.y = this.diameter/2;
        return;
      }

      if (mouseX > window.innerWidth - this.diameter/2) { // right edge
        this.x = window.innerWidth - this.diameter/2;
        this.y = mouseY;
        return;
      }

      if (mouseX < this.diameter/2) { // left edge
        this.x = this.diameter/2;
        this.y = mouseY;
        return;
      }

      if (mouseY > window.innerHeight - this.diameter/2) { // lower edge
        this.y = window.innerHeight - this.diameter/2;
        this.x = mouseX;
        return;
      }

      if (mouseY < this.diameter/2) { // upper edge
        this.y = this.diameter/2;
        this.x = mouseX;
        return;
      }
      // otherwise, ball is relocated to where the left click is
      this.x = mouseX;
      this.y = mouseY;
    } else { // right click to stop at a color, and another right will undo the it
      this.rightClick = !this.rightClick;
    }
  }

  grow() { // enlarge ball
    if (this.diameter != window.innerHeight) {
      this.diameter = this.diameter + 5;
    }
    //check bounds
    if ((this.x + this.dx > window.innerWidth - this.diameter/2 || this.x + this.dx < this.diameter/2)) {
      this.diameter -= 5;
    }
    if ((this.y + this.dy > window.innerHeight - this.diameter/2 || this.y + this.dy < this.diameter/2)) {
      this.diameter -= 5;
    }
  }

  shrink() { // shrink ball
    if (this.diameter > 5) {
      this.diameter = this.diameter - 5;
    }
  }

  stop() { // press SPACE to stop, and another the SPACE will make the ball move again
    if (this.stopState === false) { // when ball is moving, stop after SPACE
      this.dx = 0;
      this.dy = 0;
      this.stopState = !this.stopState;
    } else { // when ball is not moving, move again after SPACE
      this.dx = 3;
      this.dy = 3;
      this.stopState = !this.stopState;
    }
  }

  speedUp() { // speed up and move randomly when ENTER is being pressed
    let dxRandom = random(-50, 50);
    let dyRandom = random(-50, 50);
    this.dx = dxRandom; //change x randomly
    this.dy = dyRandom; //change y randomly
    // check bounds
    if ((this.x + dxRandom > window.innerWidth - this.diameter/2 || this.x + dxRandom < this.diameter/2)) {
      this.dx = -this.dx;
      return;
    }
    if ((this.y + dyRandom > window.innerHeight - this.diameter/2 || this.y + dyRandom < this.diameter/2)) {
      this.dy = -this.dy;
      return;
    }
  }

  toOriginalSpeed() {
    if (this.stopState == false) { // when ball was moving before ENTER, the release of ENTER will make ball move normally again
      // check bounds
      this.dx = 3;
      this.dy = 3;
      if ((this.x + 3 > window.innerWidth - this.diameter/2 || this.x + 3 < this.diameter/2)) {
        this.dx = -this.dx;
        return;
      }
      if ((this.y + 3 > window.innerHeight - this.diameter/2 || this.y + 3 < this.diameter/2)) {
        this.dy = -this.dy;
        return;
      }
    } else if (this.stopState == true) { // when ball was not moving before ENTER, the release of ENTER will stop the ball
      this.dx = 0;
      this.dy = 0;
    }
  }

  ringMode() {
    this.ring = !this.ring;
    if (this.rightClick == true) { // when ball color is fixed, the change of state from ring to ball makes ball colors go randomly again
      this.rightClick = false;
    }
  }
}
